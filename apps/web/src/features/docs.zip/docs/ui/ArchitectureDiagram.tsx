'use client';

import type { JSX } from "react"

interface ArchitectureDiagramProps {
  stepsCsv?: string
  title?: string,
}

export function ArchitectureDiagram({
  stepsCsv,
  title,
}: ArchitectureDiagramProps): JSX.Element {
  // if (!steps.length) return null
  const steps = (stepsCsv ?? "")
    .split("|")
    .map((step) => step.trim())
    .filter(Boolean)

  return (
    <div className="my-8 rounded-2xl border p-6 shadow-sm">
      {title ? (
        <p className="mb-4 text-sm font-semibold uppercase tracking-wide">
          {title}
        </p>
      ) : null}

      {steps.length === 0 ? (
        <div className="rounded-xl border border-dashed px-4 py-6 text-sm opacity-70">
          No diagram steps provided.
        </div>
      ) : (
        <>
          <div className="overflow-x-auto">
            <div className="flex min-w-max items-center gap-3 px-2">
              {steps.map((step, index) => (
                <div key={`${step}-${index}`} className="flex items-center gap-3">
                  <div className="whitespace-nowrap rounded-xl border px-4 py-3 text-sm font-medium shadow-sm">
                    {step}
                  </div>

                  {index < steps.length - 1 ? <span>→</span> : null}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 text-xs opacity-70">
            ← scroll →
          </div>
        </>
      )}
    </div>
    // <div className="my-8 rounded-2xl border p-6 shadow-sm">
    //   {title ? (
    //     <p className="mb-4 text-sm font-semibold uppercase tracking-wide">
    //       {title}
    //     </p>
    //   ) : null}

    //   {steps.length === 0 ? (
    //     <div className="rounded-xl border border-dashed px-4 py-6 text-sm">
    //       No diagram steps provided.
    //     </div>
    //   ) : (
    //     <>
    //       <div className="overflow-x-auto">
    //         <div className="flex min-w-max items-center gap-3 px-2">
    //           {steps.map((step, index) => (
    //             <div key={`${step}-${index}`} className="flex items-center gap-3">
    //               <div className="whitespace-nowrap rounded-xl border px-4 py-3 text-sm font-medium shadow-sm">
    //                 {step}
    //               </div>

    //               {index < steps.length - 1 ? <span>→</span> : null}
    //             </div>
    //           ))}
    //         </div>
    //       </div>

    //       <div className="mt-3 text-xs opacity-70">
    //         ← scroll →
    //       </div>
    //     </>
    //   )}
    // </div>


    // <div className="my-8 rounded-2xl border bg-card p-6 shadow-sm">
    //   {title && (
    //     <p className="mb-4 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
    //       {title}
    //     </p>
    //   )}

    //   <div className="relative">
    //     {/* Fade left */}
    //     <div className="pointer-events-none absolute left-0 top-0 h-full w-6 bg-gradient-to-r from-background to-transparent" />

    //     {/* Fade right */}
    //     <div className="pointer-events-none absolute right-0 top-0 h-full w-6 bg-gradient-to-l from-background to-transparent" />

    //     {/* Scroll container */}
    //     <div className="overflow-x-auto">
    //       <div className="flex min-w-max items-center gap-3 px-2">
    //         {steps.map((step, index) => (
    //           <div key={`${step}-${index}`} className="flex items-center gap-3">
    //             <div className="rounded-xl border bg-background px-4 py-3 text-sm font-medium shadow-sm whitespace-nowrap">
    //               {step}
    //             </div>

    //             {index < steps.length - 1 && (
    //               <span className="text-muted-foreground">→</span>
    //             )}
    //           </div>
    //         ))}
    //       </div>
    //     </div>
    //   </div>

    //   {/* Scroll hint */}
    //   <div className="mt-3 text-xs text-muted-foreground">
    //     ← scroll →
    //   </div>
    // </div>
  )
}