'use client';

import React, { JSX, useEffect, useMemo } from 'react';
import { skipToken } from '@tanstack/react-query';

import type { FolderNode, FileNode } from '@contracts/cloudinary/finder.types';
import { isFileNode, isFolderNode } from '@features/cloudinary-finder/guards/finder.guards';

import type { DragSource } from '@contracts/cloudinary/move.types';
import type { MoveIntent } from '@contracts/cloudinary/move.schema';

import GridFolderItem from '@features/cloudinary-finder/ui/grid/GridFolderItem';
import GridFileItem from '@features/cloudinary-finder/ui/grid/GridFileItem';

import { useSelectionStore } from '@features/cloudinary-finder/state/selection/useSelectionStore';
import { trpc } from '@trpc/trpcClient';

import BinGridFolderItem from '@features/cloudinary-finder/ui/trash/bin/BinGridFolderItem';
import BinGridFileItem from '@features/cloudinary-finder/ui/trash/bin/BinGridFileItem';
import { FolderContextMenu } from '@features/cloudinary-finder/ui/context-menus/FolderContextMenu';

import {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuSub,
  ContextMenuSubTrigger,
  ContextMenuSubContent,
} from "@components/ui/context-menu";

type Props = {
  folder: FolderNode;
  onOpenFolder: (path: string) => void;
  onSelectFile?: (file: FileNode) => void;
  onMove: (intent: MoveIntent) => void;

  onOpenTrashEntry?: (trashId: string) => void;
};

/**
 * Normalizes a given path by removing any leading or trailing forward slashes.
 *
 * @param {string} p - The path to be normalized.
 * @returns {string} - The normalized path.
 */
function normalizePath(p: string): string {
  return p.replace(/^\/+|\/+$/g, '');
}

/**
 * Checks if the given path is in a bin tree.
 * @param {string} path - The path to check.
 * @returns {boolean} - True if the path is in a bin tree, false otherwise.
 */
function isInBinTree(path: string): boolean {
  const p = normalizePath(path);
  return p.endsWith('/bin') || p.includes('/bin/');
}

function isBinRootPath(path: string): boolean {
  return normalizePath(path).endsWith('/bin');
}

function getAppRootFromPath(path: string): string {
  return normalizePath(path).split('/')[0] ?? '';
}

export default function FolderContentView({
  folder,
  onOpenFolder,
  onSelectFile,
  onMove,
  onOpenTrashEntry,
}: Props): JSX.Element {
  const subFolders = folder.children.filter(isFolderNode);
  const files = folder.children.filter(isFileNode);

  const multiSelectActive = useSelectionStore((s) => s.multiSelectActive);
  const clearNormalSelection = useSelectionStore((s) => s.clearNormalSelection);

  const binMultiSelectActive = useSelectionStore((s) => s.binMultiSelectActive);
  const binSelection = useSelectionStore((s) => s.binSelection);
  const clearBinSelection = useSelectionStore((s) => s.clearBinSelection);

  const utils = trpc.useUtils();

  const inBin = isInBinTree(folder.fullPath);
  const isBinRoot = isBinRootPath(folder.fullPath);
  const canBinMultiSelect = inBin && isBinRoot;

  const appRoot = useMemo(() => getAppRootFromPath(folder.fullPath), [folder.fullPath]);

  useEffect(() => {
    if (inBin && multiSelectActive) clearNormalSelection();
    if (!inBin && binMultiSelectActive) clearBinSelection();
  }, [inBin, multiSelectActive, binMultiSelectActive, clearNormalSelection, clearBinSelection]);

  useEffect(() => {
    if (inBin && !isBinRoot && binMultiSelectActive) {
      clearBinSelection();
    }
  }, [inBin, isBinRoot, binMultiSelectActive, clearBinSelection]);

  const listBinQueryInput = useMemo(() => {
    if (!inBin) return skipToken;
    return {
      appRoot,
      limit: 100,
      cursor: null as string | null,
      search: undefined as string | undefined,
    };
  }, [inBin, appRoot]);

  const listBin = trpc.trash.listBin.useQuery(listBinQueryInput, {
    enabled: inBin,
    refetchOnWindowFocus: false,
    staleTime: 5_000,
  });

  const trashItems = useMemo(() => {
    if (!inBin) return [];
    return listBin.data?.items ?? [];
  }, [inBin, listBin.data]);

  const selectedTrashIds = useMemo(() => Array.from(binSelection), [binSelection]);
  const hasBinSelection = selectedTrashIds.length > 0;

  const deleteForever = trpc.trash.deleteForever.useMutation({
    onSuccess: async () => {
      await utils.trash.listBin.invalidate();
      await utils.cloudinary.getFolderTree.invalidate();
      clearBinSelection();
    },
    onError: (err) => console.error('[trash.deleteForever] failed:', err),
  });

  async function handleEmptyBin() {
    const ok = confirm('⚠️ Vider la corbeille ?\n\nTout le contenu sera supprimé définitivement.');
    if (!ok) return;

    const allIds: string[] = [];
    let cursor: string | null | undefined = null;

    while (true) {
      const res = await utils.trash.listBin.fetch({
        appRoot,
        limit: 100,
        cursor,
        search: undefined,
      });

      allIds.push(...res.items.map((x: { id: string }) => x.id));
      if (!res.nextCursor) break;
      cursor = res.nextCursor;
    }

    if (allIds.length === 0) {
      alert('La corbeille est déjà vide.');
      return;
    }

    deleteForever.mutate({ appRoot, ids: allIds });
  }

  async function handleDeleteSelection() {
    if (!hasBinSelection) return;

    const ok = confirm('⚠️ Supprimer définitivement la sélection ?\n\nCette action est irréversible.');
    if (!ok) return;

    deleteForever.mutate({ appRoot, ids: selectedTrashIds });
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();

    if (inBin) return;

    const raw = e.dataTransfer.getData('application/cloudinary');
    if (!raw) return;

    const source: DragSource = JSON.parse(raw);

    const intent: MoveIntent = {
      source,
      target: {
        type: 'folder',
        fullPath: folder.fullPath,
      },
    };

    onMove(intent);
  };

  const activeMultiSelect = inBin ? binMultiSelectActive : multiSelectActive;

  return (
    <ContextMenu>
      <ContextMenuTrigger className="w-full h-full">    
      <div
        className="space-y-6 min-h-full"
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        onMouseDownCapture={(e) => {
          if (!activeMultiSelect) return;

          const el = e.target as Element | null;
          if (!el) return;

          if (el.closest('[data-no-clear-multiselect="true"]')) return;

          const insideItem = el.closest('[data-content-item="true"]');
          if (insideItem) return;

          if (inBin) clearBinSelection();
          else clearNormalSelection();
        }}
      >
        {inBin ? (
          <>
            <div className="mb-2 flex gap-2" data-no-clear-multiselect="true">
              <button
                onClick={handleEmptyBin}
                disabled={deleteForever.isPending}
                className="px-4 py-2 rounded bg-gray-100 text-gray-900 hover:bg-gray-200 disabled:opacity-50 cursor-pointer"
                title="Vider la corbeille"
              >
                🧹 Vider la corbeille
              </button>

              {canBinMultiSelect && binMultiSelectActive && (
                <button
                  onClick={handleDeleteSelection}
                  disabled={!hasBinSelection || deleteForever.isPending}
                  className="px-4 py-2 rounded bg-red-600/20 border border-red-600 hover:bg-red-600/20 disabled:opacity-50 cursor-pointer"
                  title="Supprimer la sélection"
                >
                  {deleteForever.isPending
                    ? 'Suppression…'
                    : `🗑️ Supprimer la sélection (${selectedTrashIds.length})`}
                </button>
              )}
            </div>

            <section>
              <h3 className="font-medium mb-2">Corbeille</h3>

              {listBin.isLoading ? (
                <div className="text-gray-500 italic">Chargement…</div>
              ) : trashItems.length > 0 ? (
                <div className="grid grid-cols-3 gap-4">
                  {trashItems.map((it: { id: string; publicId: string | null; kind: string; displayName: string }) => {
                    if (it.kind === 'folder') {
                      return (
                        <BinGridFolderItem
                          key={it.id}
                          trashId={it.id}
                          displayName={it.displayName}
                          canMultiSelect={canBinMultiSelect}
                          onOpen={(trashId) => onOpenTrashEntry?.(trashId)}
                        />
                      );
                    }

                    return (
                      <BinGridFileItem
                        key={it.id}
                        trashId={it.id}
                        displayName={it.displayName}
                        publicId={it.publicId ?? null}
                        canMultiSelect={canBinMultiSelect}
                        onOpen={(trashId) => onOpenTrashEntry?.(trashId)}
                      />
                    );
                  })}
                </div>
              ) : (
                <div className="text-gray-500 italic">Corbeille vide</div>
              )}
            </section>

            {deleteForever.error && (
              <p className="text-sm text-red-600">{deleteForever.error.message || 'Erreur inconnue'}</p>
            )}
          </>
        ) : (
          <>
            {subFolders.length > 0 && (
              <section>
                <h3 className="font-medium mb-2">Dossiers</h3>
                <div className="grid grid-cols-3 gap-4">
                  {subFolders.map((subFolder) => (
                    <FolderContextMenu key={subFolder.fullPath}>
                      <GridFolderItem
                        key={subFolder.fullPath}
                        folder={subFolder}
                        onOpenFolder={onOpenFolder}
                        visibleNodes={folder.children}
                      />
                    </FolderContextMenu>
                  ))}
                </div>
              </section>
            )}

            {files.length > 0 && (
              <section>
                <h3 className="font-medium mb-2">Images</h3>
                <div className="grid grid-cols-3 gap-4">
                  {files.map((file) => (
                    <GridFileItem
                      key={file.fullPath}
                      file={file}
                      onSelect={onSelectFile}
                      visibleNodes={folder.children}
                    />
                  ))}
                </div>
              </section>
            )}

            {subFolders.length === 0 && files.length === 0 && (
              <div className="text-gray-500 italic">Dossier vide</div>
            )}
          </>
        )}
      </div>
      </ContextMenuTrigger>
      <ContextMenuContent>
        <ContextMenuItem onSelect={() => onNewFolder()}>Nouveau dossier</ContextMenuItem>
        <ContextMenuItem onSelect={() => onUploadFiles()}>Importer des images</ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}